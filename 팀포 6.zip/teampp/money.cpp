#include "stdafx.h"
#include "money.h"

money::money()
{
}

money::~money()
{
}

HRESULT money::init()
{
	return S_OK;
}

void money::release()
{
}

void money::update()
{
}

void money::render()
{
}
