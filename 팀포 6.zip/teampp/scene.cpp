#include "stdafx.h"
#include "scene.h"

scene::scene()
{
}

scene::~scene()
{
}

HRESULT scene::init()
{
	IMAGEMANAGER->addImage("Ÿ��Ʋ", "images/ui/menu_start.bmp", 1280, 720, false, RGB(0, 0, 0));

	//-----------------------------------------------------------------------------------------------------------------------------//

	_StartQuit.SceneImage = IMAGEMANAGER->addImage("StartQuit", "images/ui/StartScene_Menu.bmp", 150, 114, true, RGB(255, 0, 255));
	_StartQuit._x = WINSIZEX / 2 - 350;
	_StartQuit._y = WINSIZEY / 2 + 100;

	_StartQuit._rc = RectMakeCenter(_StartQuit._x, _StartQuit._y, _StartQuit.SceneImage->getWidth(), _StartQuit.SceneImage->getHeight());

	//-----------------------------------------------------------------------------------------------------------------------------//

	IMAGEMANAGER->addImage("������", "images/ui/StartScene_Pointer.bmp", 55, 61, true, RGB(255, 0, 255));

	_Pointer._x = _StartQuit._x - 75;
	_Pointer._y = _StartQuit._y;

	_Pointer._rc = RectMakeCenter(_Pointer._x, _Pointer._y, 50, 50);

	_Pointer._PointerState = START;

	//-----------------------------------------------------------------------------------------------------------------------------//

	IMAGEMANAGER->addImage("�ε�1", "images/ui/Loading01.bmp", 1280, 720, false, RGB(0, 0, 0));
	IMAGEMANAGER->addImage("�ε�2", "images/ui/Loading02.bmp", 1280, 720, false, RGB(0, 0, 0));
	IMAGEMANAGER->addImage("�ε�3", "images/ui/Loading03.bmp", 1280, 720, false, RGB(0, 0, 0));

	_Loading = false;
	_GameStart = false;

	_LoadingCount = 0;

	//-----------------------------------------------------------------------------------------------------------------------------//

	return S_OK;
}

void scene::release()
{
	ReleaseDC(_hWnd, getMemDC());
}

void scene::update()
{

}

void scene::render()
{
	//IMAGEMANAGER->findImage("Ÿ��Ʋ")->render(getMemDC(), 0, 0);
	//IMAGEMANAGER->findImage("StartQuit")->render(getMemDC(), 0, 0);
	//IMAGEMANAGER->findImage("������")->render(getMemDC(), 0, 0);
	//IMAGEMANAGER->findImage("�ε�1")->render(getMemDC(), 0, 0);
	//IMAGEMANAGER->findImage("�ε�2")->render(getMemDC(), 0, 0);
	//IMAGEMANAGER->findImage("�ε�3")->render(getMemDC(), 0, 0);




}

void scene::PointerMove()
{
	_Pointer._rc = RectMakeCenter(_Pointer._x, _Pointer._y, 50, 50);

	if (KEYMANAGER->isOnceKeyDown(VK_DOWN) && _Pointer._PointerState == START)
	{
		_Pointer._y += 50;
		_Pointer._PointerState = QUIT;
	}
	if (KEYMANAGER->isOnceKeyDown(VK_UP) && _Pointer._PointerState == QUIT)
	{
		_Pointer._y -= 50;
		_Pointer._PointerState = START;
	}
	if (KEYMANAGER->isOnceKeyDown(VK_SPACE) && _Pointer._PointerState == START)
	{
		_Loading = true;
	}


	switch (_Pointer._PointerState)
	{
	case START:
	{

	}
	break;
	case QUIT:
	{

	}
	break;
	}
}

void scene::NotGameStartDraw(HDC hdc)
{
	if (!_GameStart)
	{
		IMAGEMANAGER->findImage("Ÿ��Ʋ")->render(hdc, 0, 0);


		IMAGEMANAGER->findImage("StartQuit")->render(hdc, _StartQuit._x, _StartQuit._y);

		//Rectangle(getMemDC(), _StartQuit._rc);

		IMAGEMANAGER->findImage("������")->render(hdc, _Pointer._x, _Pointer._y);

		//Rectangle(getMemDC(), _Pointer._rc);
	}
}

void scene::LoadingStartDraw(HDC hdc)
{
	if (_Loading)
	{
		if (_LoadingCount <= 30)
		{
			IMAGEMANAGER->findImage("�ε�1")->render(hdc, 0, 0);
		}
		if (_LoadingCount > 30)
		{
			IMAGEMANAGER->findImage("�ε�2")->render(hdc, 0, 0);
		}
		if (_LoadingCount > 60)
		{
			IMAGEMANAGER->findImage("�ε�3")->render(hdc, 0, 0);
		}
		if (_LoadingCount > 90)
		{
			IMAGEMANAGER->findImage("�ε�2")->render(hdc, 0, 0);
		}
		if (_LoadingCount > 120)
		{
			IMAGEMANAGER->findImage("�ε�1")->render(hdc, 0, 0);
		}
		if (_LoadingCount > 150)
		{
			_Loading = false;
			_GameStart = true;
		}
	}
}

void scene::LoadingCountPlus()
{
	_LoadingCount++;
}
